# Hainich: Was die Daten können

Gemeinsamer Arbeitsbereich zu den 21 Projektideen für die Daten des Nationalparks Hainich.
Jede Änderung wird mit Name und Zeitpunkt in der Versionsgeschichte der Seite gespeichert.

## Bereiche
- [Klima und Kohlenstoff](Klima%20und%20Kohlenstoff/Readme.md): Wie viel Kohlenstoff und Wasser der Wald umsetzt und wie er auf Dürre reagiert. (6 Projekte)
- [Biodiversität](Biodiversit%C3%A4t/Readme.md): Von Punktdaten zur Fläche, von Mikrohabitaten zu Arten. (7 Projekte)
- [Waldstruktur und Entwicklung](Waldstruktur%20und%20Entwicklung/Readme.md): Wie sich ein Buchenwald ohne Eingriff entwickelt und was jeder Baum wert ist. (3 Projekte)
- [Monitoring und Bereitstellung](Monitoring%20und%20Bereitstellung/Readme.md): Wie Daten fließen, zurückwirken und öffentlich werden. (5 Projekte)

## Personen und Kompetenzen
- [Personen](Personen/Readme.md): Steckbriefe, wer sich womit auskennt und angesprochen werden kann.

## So arbeiten wir hier
- Wer etwas beiträgt, schreibt es auf die Projektseite unter **Beiträge** und trägt sich bei **Ansprechpartner** ein.
- Wer etwas weiß, legt einen Steckbrief unter **Personen** an (freiwillig).
- Fragen an den Assistenten, z. B.: „Wer ist Ansprechpartner für Totholz?“ oder „Wer kennt sich mit ALS-Daten aus?“

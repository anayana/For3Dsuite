# Vorname Nachname

**Einrichtung:** 
**Rolle:** 
**Erreichbar über:** (dienstliche E-Mail oder Telefon)

## Kompetenzen
- Thema, z. B. ALS-Auswertung, Totholz, Fledermausakustik, Datenbanken

## Beteiligt an
- Projekt mit Link, eigene Rolle

## Kann gefragt werden zu
- 

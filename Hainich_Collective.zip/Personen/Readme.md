# Personen und Kompetenzen

Steckbriefe sind freiwillig. Bitte nur dienstliche Angaben.

- [Vorlage Steckbrief](Vorlage%20Steckbrief.md): kopieren und mit eigenem Namen speichern.

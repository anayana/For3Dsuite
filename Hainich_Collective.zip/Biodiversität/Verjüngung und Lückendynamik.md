# Verjüngung und Lückendynamik

**Bereich:** [Biodiversität](Readme.md)

Wo entstehen Lücken, und wie schnell schließen sie sich?

## Frage
Wie verjüngt sich der Wald ohne Eingriff?

## Daten
ALS-Zeitreihe, Satellit, Inventur, Wildkameras

## Vorgehen
Lücken aus Höhenmodellen erkennen und über alle Befliegungen verfolgen

## Ergebnis
Lückenkarte mit Alter, Verjüngung je Lücke

## Nutzen
Waldentwicklung verstehen, Lebensraum für lichtliebende Arten

## Vertiefung
- **Alter:** Lücken verschiedenen Alters vergleichen.
- **Verjüngung:** Was in den Lücken nachwächst.
- **Verbiss:** Aus den Wildkameras.

## Hängt zusammen mit
- [Waldentwicklung seit der Stilllegung](../Waldstruktur%20und%20Entwicklung/Waldentwicklung%20seit%20der%20Stilllegung.md)
- [Mikroklima-Karte](../Klima%20und%20Kohlenstoff/Mikroklima-Karte.md)
- [Wildkameras mit KI](Wildkameras%20mit%20KI.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

# Biodiversität auf die Fläche

**Bereich:** [Biodiversität](Readme.md)

Punktdaten zu Arten auf den ganzen Park hochrechnen.

## Frage
Wo kommen welche Arten vor, auch da, wo niemand gemessen hat?

## Daten
Wildkameras, Akustik, Vögel, Fledermäuse, Artfunde, ALS, TLS, Mikroklima

## Vorgehen
Artverbreitungsmodelle mit Strukturvariablen, passender Wirkradius je Artgruppe, räumliche Prüfung

## Ergebnis
Habitat- und Verbreitungskarten mit Unsicherheit

## Nutzen
FFH-Bericht, Schutzplanung, Übertragung in den Wirtschaftswald

## Vertiefung
- **Wirkradius:** Jede Artgruppe braucht ihre eigene Umgebung: Fledermäuse anders als Käfer.
- **Struktur:** ALS und TLS erklären, wo Arten vorkommen.
- **Unsicherheit:** Die Karte zeigt auch, wo sie schwach ist.

## Hängt zusammen mit
- [Mikrohabitate und Arten](Mikrohabitate%20und%20Arten.md)
- [Akustik automatisch](Akustik%20automatisch.md)
- [Wildkameras mit KI](Wildkameras%20mit%20KI.md)
- [Strukturkarte](../Waldstruktur%20und%20Entwicklung/Strukturkarte.md)
- [Mikroklima-Karte](../Klima%20und%20Kohlenstoff/Mikroklima-Karte.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

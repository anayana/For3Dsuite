# Mikrohabitate und Arten

**Bereich:** [Biodiversität](Readme.md)

Welche Baummerkmale tragen welche Arten?

## Frage
Welche Höhlen, Totäste und Rindentaschen erklären, welche Arten an einem Punkt vorkommen?

## Daten
Mikrohabitate an den Monitoringpunkten (TLS, 3DGS, Begang), Artnachweise an denselben Punkten

## Vorgehen
Mikrohabitate je Punkt erfassen und mit den Artnachweisen in Beziehung setzen

## Ergebnis
Welche Merkmale welche Arten erklären

## Nutzen
Grundlage für die Auswahl von Habitatbäumen, auch bei ThüringenForst

## Vertiefung
- **Erfassung:** Mit Rucksack und 3D Gaussian Splatting statt nur nach Augenmaß.
- **Bezug:** Gleiche Punkte, gleiche Zeit wie das Artenmonitoring.
- **Übertragung:** Daraus entsteht der Habitatwert je Baum.

## Hängt zusammen mit
- [Biodiversität auf die Fläche](Biodiversit%C3%A4t%20auf%20die%20Fl%C3%A4che.md)
- [Habitatbaum- und Totholzkarte](Habitatbaum-%20und%20Totholzkarte.md)
- [Holzwert und Habitatwert](../Waldstruktur%20und%20Entwicklung/Holzwert%20und%20Habitatwert.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

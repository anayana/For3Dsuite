# Phänologie

**Bereich:** [Biodiversität](Readme.md)

Austrieb, Laubfall und Mastjahre.

## Frage
Wird die Vegetationszeit länger, und was kosten Mastjahre?

## Daten
Sentinel-2, Kameras, Streufallen, Messturm

## Vorgehen
Zeitreihen je Pixel und Art, Abgleich mit der Photosynthese am Turm

## Ergebnis
Kalender je Jahr, Trend der Vegetationszeit

## Nutzen
Klimawirkung sichtbar machen, Zuwachs erklären

## Vertiefung
- **Mast:** Mastjahre bremsen den Stammzuwachs.
- **Vegetationszeit:** Länger oder kürzer als vor 20 Jahren?
- **Auslöser:** Probenahmen zur richtigen Zeit starten.

## Hängt zusammen mit
- [Kohlenstoffkarte und Bilanz](../Klima%20und%20Kohlenstoff/Kohlenstoffkarte%20und%20Bilanz.md)
- [Akustik automatisch](Akustik%20automatisch.md)
- [Digitaler Schatten und Zwilling](../Monitoring%20und%20Bereitstellung/Digitaler%20Schatten%20und%20Zwilling.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

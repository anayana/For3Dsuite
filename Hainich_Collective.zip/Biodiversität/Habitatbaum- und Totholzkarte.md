# Habitatbaum- und Totholzkarte

**Bereich:** [Biodiversität](Readme.md)

Wo liegt und steht wie viel Totholz, wo stehen Habitatbäume?

## Frage
Wie viel Totholz gibt es, in welcher Zersetzung, und wie gut ist es vernetzt?

## Daten
Inventur (Totholz ab 20 cm), ALS, TLS

## Vorgehen
Totholzvolumen je Probekreis, über ALS auf die Fläche, Zersetzungsstufen, Vernetzung

## Ergebnis
Totholzkarte, Dichte der Habitatbäume

## Nutzen
Pflichtindikator der EU-Wiederherstellungsverordnung, FFH-Bericht, Kohlenstoff (ca. 13,5 t C/ha)

## Vertiefung
- **Stehend:** Aus ALS gut sichtbar.
- **Liegend:** Aus TLS und Inventur.
- **Vernetzung:** Abstände zwischen Habitatinseln.

## Hängt zusammen mit
- [Kohlenstoffkarte und Bilanz](../Klima%20und%20Kohlenstoff/Kohlenstoffkarte%20und%20Bilanz.md)
- [Mikrohabitate und Arten](Mikrohabitate%20und%20Arten.md)
- [Strukturkarte](../Waldstruktur%20und%20Entwicklung/Strukturkarte.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

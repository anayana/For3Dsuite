# Akustik automatisch

**Bereich:** [Biodiversität](Readme.md)

Vögel und Fledermäuse aus Daueraufnahmen erkennen.

## Frage
Welche Arten sind wann aktiv, und wie ändert sich das über die Jahre?

## Daten
Audiorekorder, Ultraschalldetektoren

## Vorgehen
Automatische Erkennung (z. B. BirdNET), Stichproben prüfen, Aktivität je Stunde und Saison

## Ergebnis
Artenlisten, Aktivität, Trends, Phänologie

## Nutzen
Dauerhaftes Monitoring mit wenig Personal

## Vertiefung
- **Vögel:** Artenlisten und Gesangsbeginn im Jahr.
- **Fledermäuse:** Aktivität an Lücken und Altbäumen.
- **Datenmenge:** 2–10 TB pro Jahr, vor allem Ultraschall.

## Hängt zusammen mit
- [Biodiversität auf die Fläche](Biodiversit%C3%A4t%20auf%20die%20Fl%C3%A4che.md)
- [Phänologie](Ph%C3%A4nologie.md)
- [Open Data Hub](../Monitoring%20und%20Bereitstellung/Open%20Data%20Hub.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

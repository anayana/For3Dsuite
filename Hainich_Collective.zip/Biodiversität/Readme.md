# Biodiversität

Von Punktdaten zur Fläche, von Mikrohabitaten zu Arten.

## Projekte
- [Biodiversität auf die Fläche](Biodiversit%C3%A4t%20auf%20die%20Fl%C3%A4che.md): Punktdaten zu Arten auf den ganzen Park hochrechnen.
- [Mikrohabitate und Arten](Mikrohabitate%20und%20Arten.md): Welche Baummerkmale tragen welche Arten?
- [Habitatbaum- und Totholzkarte](Habitatbaum-%20und%20Totholzkarte.md): Wo liegt und steht wie viel Totholz, wo stehen Habitatbäume?
- [Akustik automatisch](Akustik%20automatisch.md): Vögel und Fledermäuse aus Daueraufnahmen erkennen.
- [Wildkameras mit KI](Wildkameras%20mit%20KI.md): Säugetiere automatisch erkennen und zählen.
- [Verjüngung und Lückendynamik](Verj%C3%BCngung%20und%20L%C3%BCckendynamik.md): Wo entstehen Lücken, und wie schnell schließen sie sich?
- [Phänologie](Ph%C3%A4nologie.md): Austrieb, Laubfall und Mastjahre.

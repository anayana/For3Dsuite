# Wildkameras mit KI

**Bereich:** [Biodiversität](Readme.md)

Säugetiere automatisch erkennen und zählen.

## Frage
Wer ist wo unterwegs, und wie stark wird verbissen?

## Daten
Wildkamerabilder

## Vorgehen
KI-Klassifikation, Stichproben prüfen, Bilder mit Personen herausfiltern

## Ergebnis
Aktivität, Verbreitung, Hinweise auf Verbiss

## Nutzen
Wildtiermonitoring, Verjüngung

## Vertiefung
- **Datenschutz:** Bilder mit Personen werden nicht veröffentlicht.
- **Verbiss:** Mit der Verjüngung in Lücken verknüpfen.
- **Datenmenge:** ca. 3 TB pro Jahr.

## Hängt zusammen mit
- [Biodiversität auf die Fläche](Biodiversit%C3%A4t%20auf%20die%20Fl%C3%A4che.md)
- [Verjüngung und Lückendynamik](Verj%C3%BCngung%20und%20L%C3%BCckendynamik.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

# Kohlenstoffkarte und Bilanz

**Bereich:** [Klima und Kohlenstoff](Readme.md)

Vorrat und Senke des ganzen Parks von 2000 bis 2025, als Karte mit Unsicherheit.

## Frage
Wie viel Kohlenstoff speichert der Hainich, und nimmt er noch zu?

## Daten
Inventur 2000/2010/2020 (393 Probekreise), 28-ha-Fläche, ALS, Messturm DE-Hai, Boden, Streu

## Vorgehen
Lokale Allometrie → Biomasse je Baum → ALS-Modell → Karte 20 m, Parksumme ± Fehler, Zeitreihe, Abgleich mit dem Turm

## Ergebnis
Kohlenstoffkarte, Unsicherheitskarte, Senke je Jahr, Projektion

## Nutzen
EU-Wiederherstellungsverordnung, Treibhausgasbericht, Argument im Haushalt

## Partner (Institutionen)
NW-FVA, MPI-BGC Jena, TLBG, Thünen-Institut

## Aufwand
ca. 12–13 Personenmonate · ca. 120 T€

## Mögliche Finanzierung
ENL Thüringen · Waldklimafonds · DFG über eine Uni · EU LIFE

## Vertiefung
- **Allometrie:** Lokale Funktionen statt Literatur. Der größte Hebel gegen systematische Fehler.
- **ALS-Modell:** Probekreise gegen ALS-Metriken, nichtlinear, räumlich kreuzvalidiert.
- **Turmabgleich:** Die Vorratsänderung muss zum Netto-Austausch passen. Der Turm misst im Mittel ca. 535 g C/m² pro Jahr, 2019–2021 nur 333–395.
- **Projektion:** Erst 2010–2023 nachrechnen, dann nach vorn. Szenarien für Klima und Eschenausfall.
- **Speicher:** Knohl: 337 t C/ha, davon Bäume 178, Wurzeln 34, Totholz 13,5, Boden 110.

## Hängt zusammen mit
- [Allometrie starker Altbuchen](Allometrie%20starker%20Altbuchen.md)
- [Dürre und Eschensterben](D%C3%BCrre%20und%20Eschensterben.md)
- [Boden und Streu](Boden%20und%20Streu.md)
- [Ökosystemleistungen in Euro](../Monitoring%20und%20Bereitstellung/%C3%96kosystemleistungen%20in%20Euro.md)
- [Digitaler Schatten und Zwilling](../Monitoring%20und%20Bereitstellung/Digitaler%20Schatten%20und%20Zwilling.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

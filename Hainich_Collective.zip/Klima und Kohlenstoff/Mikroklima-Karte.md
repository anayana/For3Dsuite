# Mikroklima-Karte

**Bereich:** [Klima und Kohlenstoff](Readme.md)

Wie stark puffert das Kronendach Hitze?

## Frage
Wo bleibt es im Sommer kühl und feucht, wo nicht?

## Daten
Mikroklima-Sensoren, ALS (Kronendichte, Lücken), Satellit

## Vorgehen
Sensorwerte gegen die Struktur modellieren und auf die Fläche hochrechnen

## Ergebnis
Karte der Temperaturpufferung, Hitzeinseln in Lücken

## Nutzen
Lebensraum für Arten, Erholung, Argument für geschlossene Altbestände

## Vertiefung
- **Pufferung:** Unterschied zwischen Wald und Freiland an heißen Tagen.
- **Lücken:** Junge und alte Lücken vergleichen.
- **Arten:** Eingangsgröße für die Habitatkarten.

## Hängt zusammen mit
- [Biodiversität auf die Fläche](../Biodiversit%C3%A4t/Biodiversit%C3%A4t%20auf%20die%20Fl%C3%A4che.md)
- [Wasserhaushalt](Wasserhaushalt.md)
- [Verjüngung und Lückendynamik](../Biodiversit%C3%A4t/Verj%C3%BCngung%20und%20L%C3%BCckendynamik.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

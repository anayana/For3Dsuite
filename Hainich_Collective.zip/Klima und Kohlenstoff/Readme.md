# Klima und Kohlenstoff

Wie viel Kohlenstoff und Wasser der Wald umsetzt und wie er auf Dürre reagiert.

## Projekte
- [Kohlenstoffkarte und Bilanz](Kohlenstoffkarte%20und%20Bilanz.md): Vorrat und Senke des ganzen Parks von 2000 bis 2025, als Karte mit Unsicherheit.
- [Allometrie starker Altbuchen](Allometrie%20starker%20Altbuchen.md): 12–15 gefällte Buchen ab 55 cm, vorher unbelaubt mit TLS gescannt.
- [Dürre und Eschensterben](D%C3%BCrre%20und%20Eschensterben.md): Wo sterben Bäume, wo verlieren Kronen, seit wann?
- [Wasserhaushalt](Wasserhaushalt.md): Wann und wo leiden die Bäume unter Trockenheit?
- [Mikroklima-Karte](Mikroklima-Karte.md): Wie stark puffert das Kronendach Hitze?
- [Boden und Streu](Boden%20und%20Streu.md): Kohlenstoff im Boden, Streufall und Abbau.

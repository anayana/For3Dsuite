# Dürre und Eschensterben

**Bereich:** [Klima und Kohlenstoff](Readme.md)

Wo sterben Bäume, wo verlieren Kronen, seit wann?

## Frage
Wie stark trifft die Trockenheit seit 2018 den alten Buchenwald, und welche Rolle spielt die Esche?

## Daten
ALS-Differenzen, Sentinel-2, Landsat, Dendrometer, Inventur

## Vorgehen
Kronenverlust aus Höhenänderungen, Vitalität aus Spektralzeitreihen, Absterben aus der Inventur

## Ergebnis
Schadens- und Vitalitätskarten seit 2018

## Nutzen
Erklärt den Rückgang der Senke, hilft bei der Verkehrssicherung, Referenz für den Waldumbau

## Partner (Institutionen)
MPI-BGC Jena, ThüringenForst, Uni Jena

## Vertiefung
- **Esche:** Esche macht ca. 25 % des Bestands aus. Starke alte Eschen bremsen seit 2018 die Aufnahme.
- **Buche:** Unterdrückte, vitale Buchen wachsen eher besser als vorher.
- **Frühwarnung:** Dendrometer zeigen Stress, bevor die Krone es zeigt.

## Hängt zusammen mit
- [Kohlenstoffkarte und Bilanz](Kohlenstoffkarte%20und%20Bilanz.md)
- [Wasserhaushalt](Wasserhaushalt.md)
- [Digitaler Schatten und Zwilling](../Monitoring%20und%20Bereitstellung/Digitaler%20Schatten%20und%20Zwilling.md)
- [Verkehrssicherung mit Habitatwert](../Monitoring%20und%20Bereitstellung/Verkehrssicherung%20mit%20Habitatwert.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

# Boden und Streu

**Bereich:** [Klima und Kohlenstoff](Readme.md)

Kohlenstoff im Boden, Streufall und Abbau.

## Frage
Wächst der Kohlenstoffspeicher im Boden weiter?

## Daten
Bodenproben 2004 und 2009, Streufallen, Bodenatmung, Messturm

## Vorgehen
Wiederbeprobung alle 10 Jahre, Bilanz aus Streufall und Atmung

## Ergebnis
Boden-Kohlenstoff je Bodeneinheit, Abbauraten

## Nutzen
Etwa ein Drittel des Kohlenstoffs liegt im Boden (ca. 110 t C/ha)

## Vertiefung
- **Wiederbeprobung:** An die Proben von 2004 und 2009 anschließen (Schrumpf et al.).
- **Totholzabbau:** Dichte je Zersetzungsstufe aus Bohrkernen.
- **Feinwurzeln:** Kleiner Vorrat (440–480 g/m²), aber schneller Umsatz.

## Hängt zusammen mit
- [Kohlenstoffkarte und Bilanz](Kohlenstoffkarte%20und%20Bilanz.md)
- [Habitatbaum- und Totholzkarte](../Biodiversit%C3%A4t/Habitatbaum-%20und%20Totholzkarte.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

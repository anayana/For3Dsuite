# Wasserhaushalt

**Bereich:** [Klima und Kohlenstoff](Readme.md)

Wann und wo leiden die Bäume unter Trockenheit?

## Frage
Wie viel Wasser verbrauchen die Bäume, und ab wann wird es knapp?

## Daten
Saftfluss, Stammabfluss, Bodenfeuchte, Mikroklima, Messturm

## Vorgehen
Transpiration je Baum und Art, Wasserbilanz je Standort, Schwellen für Trockenstress

## Ergebnis
Karte und Kalender für Trockenstress

## Nutzen
Erklärt Muster bei Zuwachs und Absterben, Grundlage für die Ökosystemleistung Wasser

## Vertiefung
- **Saftfluss:** Transpiration je Baum und Baumart.
- **Stammabfluss:** Wie viel Regen am Stamm in den Boden gelangt.
- **Schwellen:** Ab welcher Bodenfeuchte der Zuwachs stoppt.

## Hängt zusammen mit
- [Dürre und Eschensterben](D%C3%BCrre%20und%20Eschensterben.md)
- [Mikroklima-Karte](Mikroklima-Karte.md)
- [Ökosystemleistungen in Euro](../Monitoring%20und%20Bereitstellung/%C3%96kosystemleistungen%20in%20Euro.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

# Allometrie starker Altbuchen

**Bereich:** [Klima und Kohlenstoff](Readme.md)

12–15 gefällte Buchen ab 55 cm, vorher unbelaubt mit TLS gescannt.

## Frage
Wie viel Biomasse steckt wirklich in sehr dicken alten Buchen?

## Daten
Fällungen in Nachbarrevieren von ThüringenForst, TLS-Scans vor der Fällung

## Vorgehen
Stamm abschnittsweise messen, Äste wiegen, Dichte und Fäule an den Schnittflächen, Literatur als Vorinformation

## Ergebnis
Standort-Allometrie, Eichung des TLS für große Bäume, Abzug für hohle Altbäume

## Nutzen
Ab 70 cm laufen die Funktionen um bis zu 45 % auseinander, und rund 80 % der Biomasse stecken in Bäumen ab 50 cm

## Partner (Institutionen)
ThüringenForst, Uni Göttingen oder Jena, FH Erfurt, Thünen-Institut

## Aufwand
Masterarbeit, ca. 20 Feldtage · Bachelor als Vorstudie

## Vertiefung
- **Bachelor:** Vorhandene Funktionen auf die offene 28-ha-Fläche anwenden, ganz ohne Fällung.
- **Master:** 12–15 Buchen, je 4–5 in den Klassen 55–70, 70–85 und über 85 cm.
- **Wurzeln:** 3–4 Stubben ziehen und wiegen, als eigene Arbeit oder mit dem Thünen-Institut.
- **Genauigkeit:** Nur Literatur: ±21 % im Bestand. Mit 12–15 starken Buchen: 5–8 %.

## Hängt zusammen mit
- [Kohlenstoffkarte und Bilanz](Kohlenstoffkarte%20und%20Bilanz.md)
- [Holzwert und Habitatwert](../Waldstruktur%20und%20Entwicklung/Holzwert%20und%20Habitatwert.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

# Waldstruktur und Entwicklung

Wie sich ein Buchenwald ohne Eingriff entwickelt und was jeder Baum wert ist.

## Projekte
- [Waldentwicklung seit der Stilllegung](Waldentwicklung%20seit%20der%20Stilllegung.md): Wie entwickelt sich der Wald, seit er nicht mehr genutzt wird?
- [Strukturkarte](Strukturkarte.md): Altersphasen, Urwaldnähe und Strukturvielfalt.
- [Holzwert und Habitatwert](Holzwert%20und%20Habitatwert.md): Waldscan-Rucksack: Holzqualität und Habitatmerkmale je Baum aus einer Aufnahme.

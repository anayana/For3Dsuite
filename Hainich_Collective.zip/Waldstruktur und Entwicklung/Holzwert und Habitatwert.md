# Holzwert und Habitatwert

**Bereich:** [Waldstruktur und Entwicklung](Readme.md)

Waldscan-Rucksack: Holzqualität und Habitatmerkmale je Baum aus einer Aufnahme.

## Frage
Lassen sich Holzwert und Habitatwert jedes Baums gleichrangig und reproduzierbar erfassen?

## Daten
Rucksack-Scans (3D Gaussian Splatting und LiDAR), Inventur

## Vorgehen
Automatische Pipeline: BHD, Stammform, erster Grünast, Totäste, Mikrohabitate

## Ergebnis
Holzwert und Habitatwert je Baum

## Nutzen
Integrativer Naturschutz, Übertragung zu ThüringenForst (Auszeichnung, Habitatbäume)

## Aufwand
Hardware ca. 6,2 T€ · gesamt ca. 25 T€

## Vertiefung
- **Rucksack:** Zwei Laserscanner und fünf Kameras an einem Mast, eine Person trägt.
- **Promotion:** Drei Papers: Pipeline, Merkmale an Sensorstandorten, Fläche über Langzeitinventur.
- **Übertragung:** ThüringenForst als Anwender.

## Hängt zusammen mit
- [Mikrohabitate und Arten](../Biodiversit%C3%A4t/Mikrohabitate%20und%20Arten.md)
- [Allometrie starker Altbuchen](../Klima%20und%20Kohlenstoff/Allometrie%20starker%20Altbuchen.md)
- [Verkehrssicherung mit Habitatwert](../Monitoring%20und%20Bereitstellung/Verkehrssicherung%20mit%20Habitatwert.md)
- [Bildung und Öffentlichkeit](../Monitoring%20und%20Bereitstellung/Bildung%20und%20%C3%96ffentlichkeit.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

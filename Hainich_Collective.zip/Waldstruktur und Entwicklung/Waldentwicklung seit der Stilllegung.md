# Waldentwicklung seit der Stilllegung

**Bereich:** [Waldstruktur und Entwicklung](Readme.md)

Wie entwickelt sich der Wald, seit er nicht mehr genutzt wird?

## Frage
Was passiert in einem ungenutzten Buchenwald über 25 Jahre?

## Daten
Inventuren 2000/2010/2020, 28-ha-Fläche 1999–2023

## Vorgehen
Zuwachs, Absterben und Einwuchs je Baum-ID, Durchmesserverteilung über die Zeit

## Ergebnis
Dynamik. Auf der 28-ha-Fläche z. B. 519 → 439 Stämme/ha, Grundfläche 36,2 → 39,5 m²/ha

## Nutzen
Referenz für die Wiederherstellungsverordnung und das Welterbe

## Vertiefung
- **Durchmesser:** Viele dünne Bäume und ein Buckel bei 40–80 cm BHD.
- **Baumarten:** Buche stellt ca. 90 % der Stämme.
- **Referenz:** Ungenutzter Buchenwald als Maßstab für andere Wälder.

## Hängt zusammen mit
- [Kohlenstoffkarte und Bilanz](../Klima%20und%20Kohlenstoff/Kohlenstoffkarte%20und%20Bilanz.md)
- [Strukturkarte](Strukturkarte.md)
- [Verjüngung und Lückendynamik](../Biodiversit%C3%A4t/Verj%C3%BCngung%20und%20L%C3%BCckendynamik.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

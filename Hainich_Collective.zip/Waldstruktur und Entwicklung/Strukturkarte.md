# Strukturkarte

**Bereich:** [Waldstruktur und Entwicklung](Readme.md)

Altersphasen, Urwaldnähe und Strukturvielfalt.

## Frage
Wo ist der Wald wie strukturreich, in welcher Entwicklungsphase?

## Daten
ALS, TLS, Inventur

## Vorgehen
Strukturmaße je Fläche, z. B. Höhenvielfalt und Box-Dimension

## Ergebnis
Karte der Waldentwicklungsphasen

## Nutzen
FFH-Bericht, Welterbe, Eingangsgröße für die Biodiversitätsmodelle

## Vertiefung
- **Box-Dimension:** Maß für die Komplexität eines Baums aus TLS (Seidel).
- **Phasen:** Von der Verjüngung bis zum Zerfall.
- **Erklärung:** Liefert die Strukturvariablen für Biodiversität auf die Fläche.

## Hängt zusammen mit
- [Biodiversität auf die Fläche](../Biodiversit%C3%A4t/Biodiversit%C3%A4t%20auf%20die%20Fl%C3%A4che.md)
- [Habitatbaum- und Totholzkarte](../Biodiversit%C3%A4t/Habitatbaum-%20und%20Totholzkarte.md)
- [Waldentwicklung seit der Stilllegung](Waldentwicklung%20seit%20der%20Stilllegung.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

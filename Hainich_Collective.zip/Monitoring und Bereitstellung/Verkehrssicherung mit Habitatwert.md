# Verkehrssicherung mit Habitatwert

**Bereich:** [Monitoring und Bereitstellung](Readme.md)

Gefährliche Bäume an Wegen melden, mit Alternativen zum Fällen.

## Frage
Wie bleiben Wege sicher, ohne wertvolle Habitatbäume zu verlieren?

## Daten
Vitalität, Totäste (Rucksack, ALS), Wegenetz

## Vorgehen
Risiko und Habitatwert gemeinsam bewerten

## Ergebnis
Meldungen an die Ranger mit Vorschlag: Weg verlegen, sperren oder Krone einkürzen

## Nutzen
Sicherheit und Habitatbäume in einer Entscheidung

## Vertiefung
- **Risiko:** Totäste, Vitalität, Kronenverlust.
- **Habitatwert:** Höhlen und Mikrohabitate des Baums.
- **Alternative:** Lieber den Weg verlegen als den Baum fällen.

## Hängt zusammen mit
- [Digitaler Schatten und Zwilling](Digitaler%20Schatten%20und%20Zwilling.md)
- [Holzwert und Habitatwert](../Waldstruktur%20und%20Entwicklung/Holzwert%20und%20Habitatwert.md)
- [Dürre und Eschensterben](../Klima%20und%20Kohlenstoff/D%C3%BCrre%20und%20Eschensterben.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

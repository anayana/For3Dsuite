# Monitoring und Bereitstellung

Wie Daten fließen, zurückwirken und öffentlich werden.

## Projekte
- [Digitaler Schatten und Zwilling](Digitaler%20Schatten%20und%20Zwilling.md): Messungen korrigieren laufend das Modell, und das Modell steuert die Messungen.
- [Verkehrssicherung mit Habitatwert](Verkehrssicherung%20mit%20Habitatwert.md): Gefährliche Bäume an Wegen melden, mit Alternativen zum Fällen.
- [Open Data Hub](Open%20Data%20Hub.md): Ergebnisse per Knopfdruck ins Geoportal Thüringen und aufs eigene Portal.
- [Ökosystemleistungen in Euro](%C3%96kosystemleistungen%20in%20Euro.md): Kohlenstoff, Wasser und Erholung in Euro bewertet.
- [Bildung und Öffentlichkeit](Bildung%20und%20%C3%96ffentlichkeit.md): 3D-Rundgänge, Live-Messnetz und Mitmachen.

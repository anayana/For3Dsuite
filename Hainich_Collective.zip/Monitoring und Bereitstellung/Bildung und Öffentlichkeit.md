# Bildung und Öffentlichkeit

**Bereich:** [Monitoring und Bereitstellung](Readme.md)

3D-Rundgänge, Live-Messnetz und Mitmachen.

## Frage
Wie wird die Forschung im Park für Besucher und Schulen erlebbar?

## Daten
3D-Szenen (For3Dsuite), Messnetz, Forschungsergebnisse

## Vorgehen
Forschung in einfacher Sprache, Rundgänge im Besucherzentrum und online

## Ergebnis
Inhalte für Besucherzentren, Schulen und Ranger

## Nutzen
Akzeptanz für Entscheidungen, Steuergeld kommt sichtbar zurück

## Vertiefung
- **3D:** Rundgänge aus den Rucksack-Scans.
- **Live:** Das Messnetz auf dem Bildschirm.
- **Mitmachen:** Artfunde melden, Citizen Science.

## Hängt zusammen mit
- [Open Data Hub](Open%20Data%20Hub.md)
- [Holzwert und Habitatwert](../Waldstruktur%20und%20Entwicklung/Holzwert%20und%20Habitatwert.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

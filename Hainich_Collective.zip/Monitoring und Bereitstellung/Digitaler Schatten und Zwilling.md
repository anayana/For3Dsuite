# Digitaler Schatten und Zwilling

**Bereich:** [Monitoring und Bereitstellung](Readme.md)

Messungen korrigieren laufend das Modell, und das Modell steuert die Messungen.

## Frage
Wie bleibt das Bild des Waldes zwischen den Inventuren aktuell?

## Daten
Alle Messnetze, Kohlenstoffmodell

## Vorgehen
Datenassimilation. Rückwege: Messrate, Scanroute, Sensorwartung

## Ergebnis
Aktueller Zustand je Baum und Fläche mit Unsicherheit

## Nutzen
Lücken zwischen Inventuren füllen, Messaufwand gezielt einsetzen

## Vertiefung
- **Schatten:** Daten fließen automatisch ins Modell.
- **Zwilling:** Das Modell wirkt zurück auf Messung und Wald.
- **Rückwege:** Messrate, Scanroute, Sensorwartung, Verkehrssicherung.

## Hängt zusammen mit
- [Kohlenstoffkarte und Bilanz](../Klima%20und%20Kohlenstoff/Kohlenstoffkarte%20und%20Bilanz.md)
- [Verkehrssicherung mit Habitatwert](Verkehrssicherung%20mit%20Habitatwert.md)
- [Open Data Hub](Open%20Data%20Hub.md)
- [Dürre und Eschensterben](../Klima%20und%20Kohlenstoff/D%C3%BCrre%20und%20Eschensterben.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

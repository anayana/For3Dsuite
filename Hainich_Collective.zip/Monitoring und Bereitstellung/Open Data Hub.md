# Open Data Hub

**Bereich:** [Monitoring und Bereitstellung](Readme.md)

Ergebnisse per Knopfdruck ins Geoportal Thüringen und aufs eigene Portal.

## Frage
Wie kommen die Ergebnisse ohne Umwege zu Bürgern, Forschung und Behörden?

## Daten
Alle aufbereiteten Ergebnisse

## Vorgehen
QGIS mit Knopf-Pipeline → Geoproxy der TLBG; REFODAT oder Zenodo; TLUBN und GBIF

## Ergebnis
Karten im Geoportal, im GDI-DE-Katalog und bei INSPIRE; Portal mit 3D und Live-Daten

## Nutzen
Pflichten erfüllen, weniger Einzelanfragen, mehr Forschung

## Aufwand
Aufbau 80–120 T€ · Betrieb 25–45 T€ pro Jahr

## Mögliche Finanzierung
ENL Thüringen · EU LIFE · NFDI · Prototype Fund · Landeshaushalt

## Vertiefung
- **Geoportal:** Drei Wege über den Geoproxy: Dienst einbinden, Paket liefern oder Dateien mit Atom-Feed.
- **Forschungsgenehmigung:** Daten nach höchstens 2 Jahren offen ablegen, mit Kurzfassung.
- **Hardware:** Archiv 100 TB, kleine VM, Auslieferung über ein CDN.

## Hängt zusammen mit
- [Ökosystemleistungen in Euro](%C3%96kosystemleistungen%20in%20Euro.md)
- [Bildung und Öffentlichkeit](Bildung%20und%20%C3%96ffentlichkeit.md)
- [Digitaler Schatten und Zwilling](Digitaler%20Schatten%20und%20Zwilling.md)
- [Akustik automatisch](../Biodiversit%C3%A4t/Akustik%20automatisch.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 

# Ökosystemleistungen in Euro

**Bereich:** [Monitoring und Bereitstellung](Readme.md)

Kohlenstoff, Wasser und Erholung in Euro bewertet.

## Frage
Was leistet der Hainich für die Gesellschaft, in Euro?

## Daten
Kohlenstoffbilanz, Wasserhaushalt, Besucherzahlen

## Vorgehen
Kohlenstoff zum UBA-Kostensatz (350 € je t CO₂), Wasser und Erholung über anerkannte Bewertungsverfahren

## Ergebnis
Leistung pro Jahr und Hektar, mit Spanne

## Nutzen
Argument für Haushalt und Politik. Zertifikate sind nicht möglich, weil die Fläche schon geschützt ist

## Vertiefung
- **Kohlenstoff:** Beispiel: 1.000 ha alter Buchenwald binden 15.000–20.000 t CO₂ pro Jahr, das sind 5–7 Mio €.
- **Wasser:** Rückhalt und Grundwasserneubildung.
- **Erholung:** Besuche als gesellschaftlicher Wert.
- **Grenzen:** Ein Argument, kein Geldfluss.

## Hängt zusammen mit
- [Kohlenstoffkarte und Bilanz](../Klima%20und%20Kohlenstoff/Kohlenstoffkarte%20und%20Bilanz.md)
- [Wasserhaushalt](../Klima%20und%20Kohlenstoff/Wasserhaushalt.md)
- [Open Data Hub](Open%20Data%20Hub.md)

## Ansprechpartner
| Name | Rolle | Kompetenz zu diesem Projekt | Erreichbar über |
|---|---|---|---|
|  |  |  |  |

## Beiträge
_Hier ergänzen: Datum, Name, was neu ist. Die Versionsgeschichte hält zusätzlich automatisch fest, wer wann was geändert hat._

- 
